import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'patient' | 'doctor' | 'admin';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  firstName?: string;
  lastName?: string;
  specialization?: string; // for doctors
  dateOfBirth?: string; // for patients
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUserProfile: (userData: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      
      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          // In a real app, this would be an API call
          // For demo purposes, we're simulating a login
          // with hardcoded user data based on the email
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          let user: User;
          
          if (email === 'doctor@example.com') {
            user = { 
              id: '1', 
              email, 
              role: 'doctor', 
              firstName: 'Alex', 
              lastName: 'Smith',
              specialization: 'Cardiologist'
            };
          } else if (email === 'admin@example.com') {
            user = { 
              id: '2', 
              email, 
              role: 'admin', 
              firstName: 'Admin', 
              lastName: 'User' 
            };
          } else {
            user = { 
              id: '3', 
              email, 
              role: 'patient', 
              firstName: 'John', 
              lastName: 'Doe',
              dateOfBirth: '1985-05-15' 
            };
          }
          
          set({ 
            user, 
            isAuthenticated: true, 
            isLoading: false 
          });
        } catch (error) {
          set({ 
            error: 'Invalid email or password', 
            isLoading: false 
          });
        }
      },
      
      register: async (email: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          // In a real app, this would be an API call
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          const user: User = { 
            id: Date.now().toString(), 
            email, 
            role: 'patient' 
          };
          
          set({ 
            user, 
            isAuthenticated: true, 
            isLoading: false 
          });
        } catch (error) {
          set({ 
            error: 'Registration failed. Please try again.', 
            isLoading: false 
          });
        }
      },
      
      logout: () => {
        set({ 
          user: null, 
          isAuthenticated: false 
        });
      },
      
      updateUserProfile: (userData) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null
        }));
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ 
        user: state.user, 
        isAuthenticated: state.isAuthenticated 
      }),
    }
  )
);